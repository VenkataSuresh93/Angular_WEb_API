export class Withdraws{
    withdrawDate :Date;
    fromAccountNo:string;
    toAccountNo:string;
    amount:number;

}