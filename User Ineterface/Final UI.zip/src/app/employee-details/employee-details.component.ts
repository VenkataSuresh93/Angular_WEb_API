import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AccountDetails } from '../Register';
import { RegisterService } from '../Register.service';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {

  public accountDetail:AccountDetails=new AccountDetails();
  errorMsg: any;
 
  id:any;
  
  constructor(private route:ActivatedRoute,
    private employeeService:RegisterService) { 
    
   }

  
  ngOnInit() {
    const id=Number(this.route.snapshot.paramMap.get('id'));
    this.id=this.route.snapshot.params['id'];
    this.getEmpById();

    }
    getEmpById(){
      this.employeeService.getEmployeeById(2)
      .subscribe(employee => {this.accountDetail=employee;
      });
    }
   
    

}
