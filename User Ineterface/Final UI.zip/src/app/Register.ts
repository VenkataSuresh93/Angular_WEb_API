export class AccountDetails{
    id: number=0;
    accountNo: string='';
    employeeCode: string;
     firstName: string;
     lastName: string;
     fatherName: string;
     gender:string;
    email: string;
    birthDate: Date=new Date();
    }
   