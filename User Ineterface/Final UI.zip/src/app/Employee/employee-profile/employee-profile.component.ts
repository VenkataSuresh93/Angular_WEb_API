import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AccountDetails } from 'src/app/Register';
import { RegisterService } from 'src/app/Register.service';

@Component({
  selector: 'app-employee-profile',
  templateUrl: './employee-profile.component.html',
  styleUrls: ['./employee-profile.component.css']
})
export class EmployeeProfileComponent implements OnInit {
  public accountDetail:AccountDetails=new AccountDetails();
  errorMsg: any;
 
  id:any;
  
  constructor(private route:ActivatedRoute,
    private employeeService:RegisterService) { 
    
   }

  
  ngOnInit() {
    
    this.id=this.route.snapshot.params['id'];
    this.getEmpById();

    }
    getEmpById(){
      this.employeeService.getEmployeeById(1)
      .subscribe(employee => {this.accountDetail=employee;
      });
    }
   
    
  }
 





