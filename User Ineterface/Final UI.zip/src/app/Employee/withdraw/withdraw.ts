export class WithdrawDetails{
    FromAccountNo : string;
    ToAccountNo : string;
    Amount : string;
}
