export class AdminLogins{
    userName:string;
    password:string;
}