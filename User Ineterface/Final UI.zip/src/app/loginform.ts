export class EmployeeLogins{
    userName: string;
    password:string;
  }