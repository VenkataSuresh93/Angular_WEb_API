
export class PersonalBankDetails{
    bankName: string;
    accountNo:string;
    ifscCode:string;
  }













//  

//user.services.ts;

// import { Injectable } from '@angular/core';
// import { FormBuilder,FormControl,FormGroup,Validators} from '@angular/forms';

// @Injectable({
//   providedIn: 'root'
// })
// export class UserService {

//   constructor(private fb:FormBuilder) { }
//   formModel =this.fb.group(
//     {
//       EmpCode: ['',Validators.required],
//       FirstName : ['',Validators.required],
//       LastName : ['',Validators.required],
//       FatherName : ['',Validators.required],  
//       Email : ['',Validators.required],
      
      
//       form: new FormGroup({
//           username: new FormControl('', Validators.required),
//           password: new FormControl('', [Validators.required, Validators.minLength(6)]),
//           Confirmpassword: new FormControl('', [Validators.required, Validators.minLength(6)])
//       })
//     })
    
// }
